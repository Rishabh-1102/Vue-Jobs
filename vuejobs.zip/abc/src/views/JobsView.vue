<script setup>
  import Joblistings from '@/components/Joblistings.vue';
</script>

<template>
  <Joblistings/>
</template>